import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route for notifications (Email/Sheets via Google Apps Script)
  app.post("/api/notify", async (req, res) => {
    const { formData, qualificationResult } = req.body;
    
    console.log("New Lead Notification:", formData.name);

    // In a real scenario, you'd fetch a Google Apps Script URL here.
    // We'll provide the Apps Script code in the final response.
    // Example: await fetch(process.env.APPS_SCRIPT_URL, { method: 'POST', body: JSON.stringify(...) });

    res.json({ success: true, message: "Notification processed" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
